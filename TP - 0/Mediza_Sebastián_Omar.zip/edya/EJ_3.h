#ifndef EJ_3_H_INCLUDED
#define EJ_3_H_INCLUDED
/*
int test_pointer();

int test_pointer(){

    char caracter;

    char *pointer;

    *pointer=caracter;

    int *arreglo[9];

    int *puntero,*puntero_1, cadena[9]={0};

    *puntero=cadena[0];

    *puntero_1=*puntero;

    int matriz[4][3], *puntero_2;

    puntero_2=&matriz[0][0];

    return 0;

}
*/

#endif // EJ_3_H_INCLUDED
