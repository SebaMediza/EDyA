#ifndef WORD_H_INCLUDED
#define WORD_H_INCLUDED

union word{
    unsigned int data;
        struct{
            unsigned char b0;
            unsigned char b1;
            unsigned char b2;
            unsigned char b3;
        };
};

#endif // WORD_H_INCLUDED
