#ifndef P_3_H_INCLUDED
#define P_3_H_INCLUDED
#include "word.h"

#include <iostream>
using namespace std;

//*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-EJERCICIO_3-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*//

void parlabra();

void parlabra(){
word w = {0xA0B1C2D3};
cout << endl << "word: "<< hex << w.data;
w.b0 = 0xD3;
w.b1 = 0xC2;
w.b2 = 0xB1;
w.b3 = 0xA1;
cout << endl << "b0: "<< hex << int(w.b0);
cout << endl << "b1: "<< hex << int(w.b1);
cout << endl << "b2: "<< hex << int(w.b2);
cout << endl << "b3: "<< hex << int(w.b3);

cout << endl << "word: "<< hex << w.data;
}

#endif // P_3_H_INCLUDED
